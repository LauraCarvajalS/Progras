CREATE TABLE Headquarters(
    Code_h SERIAL,
    City varchar(30),
    Country varchar(30),
    Creation_Date date,
    PRIMARY KEY(Code_h)
);

CREATE TABLE Employee(
    ID_Employee varchar(10),
    Email varchar(30),
    Employees_name varchar(80),
    Salary int,
    Employees_Type varchar(15),
    City varchar(30),
    Country varchar(30),
    Headquarters_Code int,
    PRIMARY KEY (ID_Employee),
    FOREIGN KEY (Headquarters_Code) REFERENCES Headquarters(Code_h),
    CHECK(Employees_Type in ('Journalist','GlobalBoss','RedactionBoss'))
);

CREATE TABLE Edition(
    Edition_number SERIAL,
    Edition_year int,
    Edition_creation_month int,
    Creation_Date_E date,
    Live_Edition varchar(2),
    PRIMARY KEY (Edition_year, Edition_number),
    CHECK(Live_Edition in ('SI','NO'))
);

CREATE TABLE News(
    ID_News SERIAL,
    Text_N varchar(550),
    Edition_state varchar(10),
    Date_finalizes_update date,
    Spotlight varchar(2),
    Header_News varchar(200),
    Title_News varchar(50),
    ID_Edition int,
    Source_Type  varchar(30),
    ID_Author varchar(10),
    Year_Ed int,
    PRIMARY KEY (ID_News),
    FOREIGN KEY (ID_Edition,Year_Ed) REFERENCES Edition(Edition_number,Edition_year),
    FOREIGN KEY (ID_Author) REFERENCES Employee(ID_Employee),
    CHECK(Edition_state in ('draft','approved','published')),
    CHECK(Spotlight in ('SI','NO'))
);

CREATE TABLE Research_proposal(
    ID_Research SERIAL,                                  
    Start_Date_P date,
    Final_Date_P date,
    Start_Date_R date,
    Final_Date_R date,
    State_P varchar(15),
    Actualization_Date_P date,
    Research_Description varchar(1200),
    Name_proposal varchar(25),
    ID_Author varchar(10),
    PRIMARY KEY(ID_Research),
    FOREIGN KEY (ID_Author) REFERENCES Employee(ID_Employee),
    CHECK(State_P in ('proposal','rejected','approved','finished'))
);

CREATE TABLE Thematic_Area(
    ID_Area int,
    Area_Name varchar (20),
    PRIMARY KEY (ID_AREA)
);

CREATE TABLE Participating_Journalist(
    ID_Employee varchar(10),
	ID_Research int,
    PRIMARY KEY(ID_Employee,ID_Research),
	FOREIGN KEY (ID_Employee) REFERENCES Employee(ID_Employee),
	FOREIGN KEY (ID_Research) REFERENCES Research_proposal(ID_Research)
);

CREATE TABLE Specialty(
    ID_Employee varchar(10),
	ID_Area int,
    PRIMARY KEY(ID_Employee, ID_Area),
    FOREIGN KEY (ID_Employee) REFERENCES Employee(ID_Employee),
    FOREIGN KEY (ID_Area) REFERENCES Thematic_Area(ID_Area)
);
CREATE TABLE Information_Agency ( 
    Link_Agencia varchar (100),
    ID_AI int,
    ID_News int,
    PRIMARY KEY(ID_AI),
    FOREIGN KEY (ID_News) REFERENCES News(ID_News)
);    

CREATE TABLE News_area (
    ID_News int,
    ID_Area int,
    PRIMARY KEY (ID_News,ID_Area),
    FOREIGN KEY (ID_News) REFERENCES News(ID_News),
    FOREIGN KEY (ID_Area) REFERENCES Thematic_Area(ID_Area)
);


---------------------------------------------------------------------
--REGISTRAR
CREATE FUNCTION R_Headquarters(City_I varchar(30),Country_I varchar(30),
    Creation_Date_I date)
    RETURNS void
    AS $$
BEGIN
	INSERT INTO Headquarters(City,Country,Creation_Date)
    VALUES(City_I,Country_I,Creation_Date_I);
END;
$$ LANGUAGE plpgsql;

----------
CREATE FUNCTION R_Employee (ID_Employee_I varchar(10),
    Email_I varchar(30),Employees_name_I varchar(80),
    Salary_I int,Employees_Type_I varchar(15),
    City_I varchar(30),Country_I varchar(30),Headquarters_Code_I INT)
    RETURNS void
    AS $$
   
BEGIN
	INSERT INTO Employee(ID_Employee,Email,Employees_name,Salary,
    Employees_Type,City,Country,Headquarters_Code)
    VALUES(ID_Employee_I,Email_I,Employees_name_I,Salary_I,
    Employees_Type_I,City_I,Country_I,Headquarters_Code_I);
END;
$$ LANGUAGE plpgsql;

-----------
CREATE FUNCTION R_News(Text_I varchar(550),Status_I varchar(10),
    Date_of_last_update_I date, Spotlight_I varchar(2),
    Header_I varchar(200),Title_news_I varchar(50),
    ID_Edition_I int, Source_type_I varchar,ID_Author_I varchar(10),
    Year_Ed_I int)
    RETURNS void
    AS $$
    
BEGIN
	INSERT INTO News(Text_N, Edition_state, Date_finalizes_update, Spotlight,
    Header_News, Title_news, ID_Edition, Source_type, ID_Author, Year_Ed)
    VALUES (Text_I, 'draft', Date_of_last_update_I, Spotlight_I,Header_I, 
            Title_news_I, ID_Edition_I, Source_type_I, ID_Author_I,Year_Ed_I);
END;
$$ LANGUAGE plpgsql;

----------
CREATE FUNCTION R_Thematic_Area(ID_Area_I int,Area_Name_I varchar(20))
    RETURNS void
    AS $$
    
BEGIN
	INSERT INTO Thematic_Area(ID_Area,Area_Name)
    VALUES (ID_Area_I,Area_Name_I);
END;
$$ LANGUAGE plpgsql;

----------
CREATE FUNCTION R_Edition(Edition_year int,
    Edition_creation_month int,Creation_Date_E date,Live_Edition varchar(2))
RETURNS void
AS $$
BEGIN
	INSERT INTO Edition (Edition_year, Edition_creation_month, Creation_Date_E, Live_Edition) 
    VALUES (Edition_year, Edition_creation_month, Creation_Date_E, Live_Edition);
END;
$$ LANGUAGE plpgsql;
----------
CREATE FUNCTION R_Research_proposal(Start_Date_P_I date,Final_Date_P_I date,Start_Date_R_I date,Final_Date_R_I date,
    State_P_I varchar(15),Actualization_Date_P_I date,Research_Description_I varchar(1200),Name_proposal_I varchar(25),ID_Author_I varchar(10))
RETURNS void
AS $$
BEGIN
	INSERT INTO Research_proposal(Start_Date_P,Final_Date_P,
    Start_Date_R ,Final_Date_R,State_P,Actualization_Date_P,
    Research_Description,Name_proposal,ID_Author) 
    VALUES (Start_Date_P_I,Final_Date_P_I,Start_Date_R_I,Final_Date_R_I,
    State_P_I,Actualization_Date_P_I,Research_Description_I,Name_proposal_I,ID_Author_I);
END;
$$ LANGUAGE plpgsql;
----------
--Create empleados-sede
---------------------------------------------------
--DELETE
CREATE FUNCTION D_Headquarters(Code_I INT)
  RETURNS void          
  AS $$  
BEGIN 
	DELETE FROM Headquarters WHERE Code_h = Code_I;
END;

$$ LANGUAGE plpgsql;

---------
CREATE FUNCTION D_Employee(ID_Employee_I varchar(10))
    RETURNS void
    AS $$        
BEGIN 
	DELETE FROM Employee 
    WHERE ID_Employee = ID_Employee_I;
END;

$$ LANGUAGE plpgsql;
---------
CREATE FUNCTION D_News(ID_News_I INT)
    RETURNS void
    AS $$        
BEGIN 
	DELETE FROM News 
    WHERE ID_News = ID_News_I;
END;

$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION D_Thematic_Area(ID_Area_I int)
	RETURNS void
	AS $$
BEGIN
     DELETE FROM Thematic_Area 
     WHERE ID_Area_I = ID_Area_I;
END;
$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION D_Editions(D_Edition_number int, D_Edition_year int)
RETURNS void
AS $$
BEGIN
	DELETE FROM Edition 
    WHERE Edition_number = D_Edition_number AND Edition_year = D_Edition_year;
END;
$$ LANGUAGE plpgsql;
-------
CREATE FUNCTION D_Research_proposal(ID_Research_I int)
RETURNS void
AS $$
BEGIN
	DELETE FROM Research_proposal
    WHERE ID_Research = ID_Research_I;
END;
$$ LANGUAGE plpgsql;
------------------------------------------------------
--UPDATE
CREATE FUNCTION Update_Headquarts (U_Code INT,U_City varchar(30),
    U_Country varchar(30))
RETURNS BOOLEAN
AS $$
BEGIN
	UPDATE Headquarters
    SET City = U_City,
    	Country = U_Country
    WHERE Code_h = U_Code;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;
-------
CREATE FUNCTION U_Employee (ID_Employee_I varchar(10),
    Email_I varchar(30),Employees_name_I varchar(80),
    Salary_I int,Employees_Type_I varchar(15),
    City_I varchar(30),Country_I varchar(30),Headquarters_Code_I INT)
    
    RETURNS BOOLEAN
    AS $$
BEGIN
	UPDATE Employee 
    SET Email= Email_I,
    Employees_name = Employees_name_I,
    Salary = Salary_I,
    Employees_Type = Employees_Type_I,
    City= City_I,Country = Country_I,
    Headquarters_Code = Headquarters_Code_I
    WHERE ID_Employee = ID_Employee_I;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

------
CREATE FUNCTION U_Thematic_Area(ID_Area_I int,Area_Name_I varchar (20))
    RETURNS BOOLEAN
    AS $$
    
BEGIN
	UPDATE Thematic_Area
    SET Area_Name= Area_Name_I
    WHERE ID_Area= ID_Area_I;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

------
CREATE FUNCTION U_Editions (
    Update_Edition_number int, Update_Edition_year int,
    Update_Live_Edition varchar(2))
RETURNS BOOLEAN
AS $$
BEGIN
	UPDATE Edition
    SET Live_Edition = Update_Live_Edition
    WHERE Edition_number = Update_Edition_number AND Edition_year = Update_Edition_year;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

--------
CREATE FUNCTION Update_News (U_ID_News INT,
    U_Text_N varchar(550),
    U_Edition_state varchar(10),
    U_Date_finalizes_update date,
    U_Spotlight varchar(2),
    U_Header_News varchar(200),
    U_Title_News varchar(50),
    U_ID_Edition int,
    U_Source_Type  varchar(30),
    U_ID_Author varchar(10),
    U_Year_Ed int
)
RETURNS BOOLEAN

AS $$
BEGIN
	UPDATE News
    SET Text_N = U_Text_N,
        Edition_state = U_Edition_state,
        Date_finalizes_update = U_Date_finalizes_update,
        Spotlight = U_Spotlight,
        Header_News = U_Header_News,
        Title_News = U_Title_News,
        ID_Edition = U_ID_Edition,
        Source_Type = U_Source_Type,
    	ID_Author = U_ID_Author,
    	Year_Ed = U_Year_Ed
    WHERE ID_News = U_ID_News;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

----------
CREATE FUNCTION U_Research_proposal(ID_Research_I INT,Start_Date_P_I date,Final_Date_P_I date,Start_Date_R_I date,Final_Date_R_I date,
    State_P_I varchar(15),Actualization_Date_P_I date,Research_Description_I varchar(1200),Name_proposal_I varchar(25),ID_Author_I varchar(10))
RETURNS BOOLEAN

AS $$
BEGIN
	UPDATE Research_proposal
    SET Start_Date_P= Start_Date_P_I,
    Final_Date_P= Final_Date_P_I,
    Start_Date_R= Start_Date_R_I,
    Final_Date_R= Final_Date_R_I,
    State_P= State_P_I,
    Actualization_Date_P = Actualization_Date_P_I,
    Research_Description = Research_Description_I,
    Name_proposal = Name_proposal_I,
    ID_Author = ID_Author_I 
    WHERE ID_Research = ID_Research_I;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;
-------
--SELECT 
CREATE FUNCTION S_Editions ()
	RETURNS TABLE 
    (
        Edition_number int,
        Edition_year int,
        Edition_creation_month int,
        Creation_Date_E date,
        Live_Edition varchar(2)
    )
AS $$
BEGIN 
 RETURN QUERY 
 SELECT *
 FROM Edition;
END;
$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION S_Headquarters()
	RETURNS TABLE
    (Code_h INT, City varchar(30),Country varchar(30),
    Creation_Date date)
    AS $$
BEGIN
	RETURN QUERY
    SELECT*
	FROM Headquarters;
END;
$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION S_Employee ()
	RETURNS TABLE
    (ID_Employee varchar(10),Email varchar(30),Employees_name varchar(80),
    Salary int,Employees_Type varchar(15),City varchar(30),Country varchar(30),Headquarters_Code INT)
    
    AS $$  
BEGIN
	RETURN QUERY
	SELECT *
    FROM Employee;
END;
$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION S_News()
	RETURNS TABLE(
    ID_News INT,Text_N varchar(550),Status varchar(10),
    Date_of_last_update date, Spotlight varchar(2),
    Header_News varchar(200),Title_news varchar(50),
    ID_Edition int,Source_Type  varchar(30),
    ID_Author varchar(10),
    Year_Ed int)
    AS $$
BEGIN
	RETURN QUERY
    SELECT *
	FROM News;
END;
$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION S_Thematic_Area()
    RETURNS TABLE(ID_Area int , Area_Name varchar (20))
    AS $$
BEGIN
	RETURN QUERY
	SELECT *
    FROM Thematic_Area;
END;
$$ LANGUAGE plpgsql;
--------
CREATE FUNCTION S_Research_proposal()
RETURNS TABLE (ID_Research INT,Start_Date_P date,
    Final_Date_P date,Start_Date_R date,
    Final_Date_R date, State_P varchar(15),
    Actualization_Date_P date,Research_Description varchar(1200),
    tema_propuesta varchar(25),ID_Author varchar(10))
AS $$
BEGIN
	RETURN QUERY 
    SELECT *
    FROM Research_proposal;
END;
$$ LANGUAGE plpgsql;
--------AGE plpgsql;

---ConsultarTipoEmpleado
CREATE FUNCTION S_TypeEmployee(name_employee varchar(80))
	RETURNS varchar 
    AS $$
DECLARE
BEGIN
    RETURN Employees_Type
    FROM Employee
    WHERE  employees_name = name_employee;
END;
$$ LANGUAGE plpgsql;

---ConsultarSedeEmpleado
CREATE FUNCTION S_SedeEmployee(name_employee varchar(80))
	RETURNS varchar 
    AS $$
DECLARE
BEGIN
    RETURN headquarters_code
    FROM Employee
    WHERE  employees_name = name_employee;
END;
$$ LANGUAGE plpgsql;

---SpotlightNews
CREATE FUNCTION U_Spotlight(U_ID_News INT,
    U_Spotlight varchar(2)
)
RETURNS BOOLEAN

AS $$
BEGIN
	UPDATE News
    SET Spotlight = U_Spotlight
    WHERE ID_News = U_ID_News;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;


----Add Specialty
CREATE FUNCTION r_specialty(id_employee_I varchar(10),
	id_area_I int)
RETURNS void
AS $$
BEGIN
	INSERT INTO specialty(id_employee,id_area)
    VALUES(id_employee_I,id_area_I);
END;
$$ LANGUAGE plpgsql;

----Delete Specialty
CREATE FUNCTION D_specialty(id_employee_I varchar(20),id_area_I int)
RETURNS void
AS $$
BEGIN
     DELETE FROM specialty 
     WHERE id_employee = id_employee_I AND id_area = id_area_I;
END;
$$ LANGUAGE plpgsql;

----Add Areas-News
CREATE FUNCTION r_news_area(id_news_I int, id_area_I int)
RETURNS void
AS $$
BEGIN
	INSERT INTO news_area(id_news, id_area)
    VALUES(id_news_I, id_area_I);
END;
$$ LANGUAGE plpgsql;

----Delete Areas-News
CREATE FUNCTION D_news_area(id_news_I int, id_area_I int)
RETURNS void
AS $$
BEGIN
     DELETE FROM news_area 
     WHERE id_area = id_area_I AND id_news = id_news_I;
END;
$$ LANGUAGE plpgsql;

----Add participating journalist
CREATE FUNCTION r_participating_journalist(id_employee_I varchar(10), id_research_I int)
RETURNS void
AS $$
BEGIN
	INSERT INTO participating_journalist(id_employee, id_research)
    VALUES(id_employee_I, id_research_I);
END;
$$ LANGUAGE plpgsql;

----Delete participating journalist
CREATE FUNCTION D_participating_journalist(id_employee_I varchar(10), id_research_I int)
RETURNS void
AS $$
BEGIN
     DELETE FROM participating_journalist 
     WHERE id_employee = id_employee_I AND id_research = id_research_I;
END;
$$ LANGUAGE plpgsql;

----Ver ediciones - Ciudad
CREATE FUNCTION S_editions_city(Edition_number_I int,Edition_year_I int)
RETURNS TABLE (Edition_number int, Edition_year int, Title_news varchar(50), City varchar(30))
AS $$
BEGIN
	RETURN QUERY 
    SELECT Edition.edition_number, Edition.edition_year, News.title_news, Headquarters.city
    FROM (Edition JOIN (News JOIN (Employee JOIN Headquarters
                                   ON Employee.headquarters_code = Headquarters.code_h)
                        ON News.id_author = Employee.id_employee)
          ON Edition.edition_number = News.id_edition
          AND Edition.edition_year = News.year_ed)
    WHERE Edition.edition_number = Edition_number_I
    AND Edition.edition_year = Edition_year_I;
END;
$$ LANGUAGE plpgsql;

/*
-----Register Users    
CREATE FUNCTION R_Users(usuario_I varchar(80), pass_I varchar(10))
RETURNS boolean
AS $$
BEGIN
	CREATE USER usuario_I WITH PASSWORD ||pass_I||;
    ALTER ROLE usuario_I WITH SUPERUSER;
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-----Delete users
CREATE FUNCTION D_Users(usuario_I varchar(80))
AS $$
BEGIN
	DROP USER usuario_I;
END;
$$ LANGUAGE plpgsql;

SELECT D_Employee('10')
SELECT * FROM Employee*/

CREATE FUNCTION Top_Agencias()
	RETURNS TABLE(
    id_ai int,link_agencia varchar(100) ,CantidadNoticias bigint )
    AS $$
BEGIN
	RETURN QUERY
    Select information_agency.id_ai, information_agency.link_agencia, count(*) as CantidadNoticias
	from information_agency 
	join news 
	on information_agency.id_news= news.id_news 
	group by information_agency.link_agencia,information_agency.id_ai;    
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION Top3()
	RETURNS TABLE(
     edition_number int, edition_year int, EditioNews bigint)
     AS $$
BEGIN 
	RETURN QUERY
  	select edition.edition_number,edition.edition_year, count(*) as EditioNews
    from edition join news 
    on edition.edition_number= news.id_edition 
    group by edition.edition_number,edition.edition_year limit 5;
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION GeneralR()
	RETURNS TABLE(
     id_research int, start_date_p date, final_date_p date, start_date_r date, final_date_r date, state_p varchar(15)
        ,actualization_date_p date, research_description varchar(1200), name_proposal varchar(25),id_author varchar(10))
     AS $$
BEGIN 
	RETURN QUERY
  	select * from research_proposal;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION GeneralNoticias()
	RETURNS TABLE(
    id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int )
    AS $$
BEGIN
	RETURN QUERY
    Select * from news;    
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION Top2()
	RETURNS TABLE(
     employees_name varchar(80), JournalistP bigint)
     AS $$
BEGIN 
	RETURN QUERY
  	select employee.employees_name, count(*) 
    from employee join research_proposal 
    on employee.id_employee= research_proposal.id_author where EXTRACT(ISOYEAR FROM actualization_date_p)='2018'--Top 5 periodistas con mas propuestas ???
    group by employee.employees_name limit 5;      
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION Resumengeneralcosto()
	RETURNS TABLE(
     CantEmpleados bigint, PromedioSalarial numeric, SaalariosSum bigint)
     AS $$
BEGIN 
	RETURN QUERY
  	select count(*) as CantEmpleados, avg(salary) as PromedioSalarial,sum(salary) as SalariosSum 
	from employee; 
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION Top1()
	RETURNS TABLE(
     employees_name varchar(80), JournalistNews bigint)
     AS $$
BEGIN 
	RETURN QUERY
  	select employee.employees_name, count(*) 
	from employee    --Top 5 periodistas con mas noticias???
	join news 
	on employee.id_employee= news.id_author  where EXTRACT(ISOYEAR FROM date_finalizes_update)='2015'
	group by employee.employees_name limit 5; 
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION TOP2F (Year_R int)
	RETURNS TABLE(
     EMPLOYEES_NAME VARCHAR(80), Research_P bigint)
     AS $$
BEGIN
	RETURN QUERY
    select employee.employees_name, count(*) as Research_P
  	from employee join research_proposal
	on employee.id_employee= research_proposal.id_author where EXTRACT(ISOYEAR FROM actualization_date_p)= Year_R
	group by employee.employees_name limit 5;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION TOP3Fi (Year_R int)
	RETURNS TABLE(
     edition_number int, edition_year int, EditionNews bigint)
     AS $$
BEGIN
	RETURN QUERY
    select edition.edition_number,edition.edition_year, count(*) as EditionNews
	from edition join news
	on edition.edition_number= news.id_edition where EXTRACT(ISOYEAR FROM date_finalizes_update)=Year_R
	group by edition.edition_number,edition.edition_year limit 5;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION TOP4Fi (Year_R int)
	RETURNS TABLE(
     id_ai int , link_agencia varchar(100), total bigint)
     AS $$
BEGIN
	RETURN QUERY
    Select information_agency.id_ai, information_agency.link_agencia, count(*) as total
    from information_agency
    join news
    on information_agency.id_news= news.id_news where EXTRACT(ISOYEAR FROM date_finalizes_update)= Year_R
    group by information_agency.link_agencia,information_agency.id_ai;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION NBY(YearR int)
	RETURNS TABLE(
     edition_number int, total bigint)
     AS $$
BEGIN
	RETURN QUERY
  	select edition.edition_number, count(*) as total
    from edition join news
    on edition.edition_number = id_edition
    where edition_year= YearR
    group by edition.edition_number;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION TOP1F(Year_R int)
	RETURNS TABLE(
     edition_number varchar(80), total bigint)
     AS $$
BEGIN
	RETURN QUERY
  	select employee.employees_name, count(*) as total
    from employee    
    join news
    on employee.id_employee= news.id_author  where EXTRACT(ISOYEAR FROM date_finalizes_update)= Year_R
    group by employee.employees_name limit 5;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION NewsF(Fecha1 DATE, Fecha2 Date)
	RETURNS TABLE( id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int) 
     AS $$
BEGIN
	RETURN QUERY
  	Select * from news
	where news.date_finalizes_update >Fecha1
	and news.date_finalizes_update < Fecha2;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION NBM(Mes_R int)
	RETURNS TABLE(
     edition_number int, total bigint)
	AS $$
BEGIN
	RETURN QUERY
  	select edition.edition_number, count(*)
    from edition join news
    on edition.edition_number = id_edition
    where edition_creation_month= Mes_R
    group by edition.edition_number;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION NewsP (Nombre varchar(80) )
	RETURNS TABLE(
      id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int )
     AS $$
BEGIN
	RETURN QUERY
  	Select news.id_news,news.text_n,news.edition_state, news.date_finalizes_update, news.spotlight,
    news.header_news, news.title_news, news.id_edition, news.source_type,news.id_author,news.year_ed  from news
	join employee
	on news.id_author= employee.id_employee
	where employee.employees_name=nombre;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION NewsE (Nombre varchar(80) )
	RETURNS TABLE(
      id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int )
     AS $$
BEGIN
	RETURN QUERY
  	Select * from news
	where news.edition_state = nombre;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION NewsA (Nombre varchar(80) )
	RETURNS TABLE(
      id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int )
     AS $$
BEGIN
	RETURN QUERY
  	Select news.id_news,news.text_n,news.edition_state, news.date_finalizes_update, news.spotlight
    ,news.header_news, news.title_news, news.id_edition, news.source_type,news.id_author,news.year_ed  from news
	join news_area
	on news.id_news = news_area.id_news
	join thematic_area
	on news_area.id_area= thematic_area.id_area where area_name = Nombre;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION R_PAE(Periodista varchar(80), Estado varchar(15))
	RETURNS TABLE(
      id_research int, start_date_p date, final_date_p date, start_date_r date, final_date_r date, 
        state_p varchar(15),actualization_date_p date, research_description varchar(1200), 
        name_proposal varchar(25),id_author varchar(10)) 
     AS $$
BEGIN
	RETURN QUERY
  	Select research_proposal.id_research, research_proposal.start_date_p, research_proposal.final_date_p, 
    research_proposal.start_date_r, research_proposal.final_date_r, research_proposal.state_p ,
    research_proposal.actualization_date_p, research_proposal.research_description, research_proposal.name_proposal,
    research_proposal.id_author
        from research_proposal
	join employee
	on research_proposal.id_author= employee.id_employee
	where employee.employees_name= Periodista and research_proposal.state_p= Estado;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION Area(Area varchar(20))
	RETURNS TABLE( Total_Empleados bigint, Promedio_Salarial numeric, Total_Salarial bigint) 
     AS $$
BEGIN
	RETURN QUERY
  	SELECT COUNT(*) AS Total_Empleados, AVG(salary) AS Promedio_Salarial, SUM(salary) AS Total_Salarial
	FROM employee JOIN specialty ON employee.id_employee= specialty.id_employee
	JOIN thematic_area ON specialty.id_area= thematic_area.id_area WHERE area_name =Area;
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION MostrarPFN(DiaS INT, MesS int, YearS int, DiaF int, MesF int, YearF int, Propuesta varchar(25))
	RETURNS TABLE( id_research int, start_date_p date, final_date_p date, start_date_r date, final_date_r date, 
        state_p varchar(15),actualization_date_p date, research_description varchar(1200), 
        name_proposal varchar(25),id_author varchar(10)) 
     AS $$
BEGIN
	RETURN QUERY
    SELECT * FROM research_proposal
    WHERE EXTRACT(Day FROM research_proposal.start_date_r)=DiaS
    AND EXTRACT(Month FROM research_proposal.start_date_r)= MesS
    AND EXTRACT(ISOYEAR FROM research_proposal.start_date_r)=YearS
    AND EXTRACT(Day FROM research_proposal.final_date_r)= DiaF
    AND EXTRACT(Month FROM research_proposal.final_date_r)= MesF
    AND EXTRACT(ISOYEAR FROM research_proposal.final_date_r)= YearF
    AND research_proposal.name_proposal= Propuesta;
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION Global(CodigoSede int)
	RETURNS TABLE(
     CantEmpleados bigint, PromedioSalarial numeric , TotalSalario bigint)
     AS $$
BEGIN
	RETURN QUERY
  	select Count(id_employee) as CantEmpleados, avg(Salary) as PromedioSalarial, 
	Sum(Salary) as TotalSalario  
	from  headquarters join employee 
	on headquarters.code_h = employee.headquarters_code
	join news
	on news.id_author=employee.id_employee
	join edition
	on news.id_edition= edition_number where code_h= CodigoSede;
END;
$$ LANGUAGE plpgsql;

-------------------------
CREATE FUNCTION Ediciones (CodigoSede int )
	RETURNS TABLE(
     Cant_Ediciones bigint, Cantidad_Noticias bigint, Promedio_Noticias numeric)
     AS $$
BEGIN
	RETURN QUERY
    select  count(distinct(edition.edition_number))as Cant_Ediciones, count(edition.edition_number) as Cantidad_Noticias, avg(edition.edition_number) as Promedio_Noticias
    from  headquarters join employee 
    on headquarters.code_h = employee.headquarters_code
    join news
    on news.id_author=employee.id_employee
    join edition
    on news.id_edition= edition_number where code_h= CodigoSede
    Group by edition.edition_number;
END;
$$ LANGUAGE plpgsql;

----------------------------------------------
CREATE FUNCTION S_news_total()
	RETURNS TABLE
    (id_news int, title_news varchar)
    AS $$
BEGIN
	RETURN QUERY
    Select id_news , title_news
    From news;
END;
$$ LANGUAGE plpgsql;

---------------------------------------------
CREATE FUNCTION S_news_display1(id_news_I int)
	RETURNS TABLE
    (area_name varchar, title_news varchar, id_employee varchar,
     date_finalizes_update date,header_news varchar,text_n varchar)
    AS $$
BEGIN
	RETURN QUERY
    Select thematic_area.area_name, news.title_news, employee.id_employee,news.date_finalizes_update,
    news.header_news,news.text_n
    From employee 
    inner join(news 
    inner join(news_area 
    inner join thematic_area ON thematic_area.id_area = news_area.id_area)
    On news.id_news= news_area.id_news)
    On news.id_author = employee.id_employee
    Where news.id_news = id_news_I;
END;
$$ LANGUAGE plpgsql;

----------------------------------------------

CREATE FUNCTION pagxte(Area varchar(20))
	RETURNS TABLE(
    title_news varchar(50), header_news varchar(200) )
    AS $$
BEGIN
	RETURN QUERY
   	select news.title_news, news.header_news from edition join news
	on edition.edition_number= news.id_edition JOIN news_Area on news.id_news= news_area.id_news join thematic_area
    on news_area.id_area=thematic_area.id_area 
	where EDITION.live_edition ='Si' and thematic_area.area_name= Area;     
END;
$$ LANGUAGE plpgsql;

-------Titulo Breaking News Recientes
CREATE FUNCTION S_BreakingNews()
RETURNS TABLE (title_news varchar(80))
AS $$
BEGIN
	RETURN QUERY 
    SELECT News.title_news FROM News
    WHERE News.date_finalizes_update  = (
        SELECT MAX(News.date_finalizes_update)
        FROM News) AND News.source_type = 'Breaking News';
END;
$$ LANGUAGE plpgsql;

-------Historia Breaking News 24h
CREATE FUNCTION S_BreakingNews24h()
RETURNS TABLE (title_news varchar(80), text_n varchar(550))
AS $$
BEGIN
	RETURN QUERY 
    SELECT News.title_news, News.text_n FROM News
    WHERE ((News.date_finalizes_update < current_date 
    AND News.date_finalizes_update > current_date-1)
    OR (News.date_finalizes_update = current_date)
    OR (News.date_finalizes_update = current_date-1))
    AND News.source_type = 'Breaking News';
END;
$$ LANGUAGE plpgsql;

-------------------------------------------
CREATE FUNCTION EdicionesPasadas(YearD int, MonthE int)
RETURNS TABLE (EDITION_NUMBER INT, EDITION_YEAR INT, EDITION_CREATION_MONTH INT, CREATION_DATE_E DATE, LIVE_EDITION VARCHAR(2))
AS $$
BEGIN
	RETURN QUERY
  	SELECT * 
    FROM EDITION 
    WHERE EDITION.EDITION_YEAR = YearD 
    AND EDITION.EDITION_CREATION_MONTH = MonthE 
    AND EDITION.LIVE_EDITION='NO'; 
END;
$$ LANGUAGE plpgsql;

-------------------------------------------

CREATE FUNCTION EdicionesPasadasInf(ID_E int )
	RETURNS TABLE(
     id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int)
     AS $$
BEGIN
	RETURN QUERY
  	select news.id_news,news.text_n  ,news.edition_state , 
        news.date_finalizes_update , news.spotlight , news.header_news, news.title_news, news.id_edition , 
        news.source_type, news.id_author, news.year_ed
        FROM EDITION join NEWS ON EDITION.EDITION_NUMBER= NEWS.ID_EDITION 
WHERE EDITION.EDITION_YEAR= ID_E;
END;
$$ LANGUAGE plpgsql;

-------------------------------------------

CREATE FUNCTION Cantidad_not()
	RETURNS TABLE(
     edition_number int, Cant_Noticias bigint)
     AS $$
BEGIN 
	RETURN QUERY
  	select edition.edition_number, count(*) as Cant_Noticias
	from edition join news 
	on edition.edition_number = id_edition -- Cantidad de noticias
	group by edition.edition_number;
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION Principales()
	RETURNS TABLE(
     spotlight varchar(2), header_news varchar(200), title_news varchar(50))
     AS $$
BEGIN
	RETURN QUERY
  	select news.title_news, news.header_news, news.spotlight from edition join news
	on edition.edition_number= news.id_edition
	where live_edition ='SI' and news.spotlight='SI' ; 
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION VerInfoNoticiasE(title_newsR varchar(50))
	RETURNS TABLE(
    id_news int,text_n varchar(550) ,edition_state varchar(10), 
        date_finalizes_update date, spotlight varchar(2), header_news varchar(200), title_news varchar(50) , id_edition int, 
        source_type varchar(30), id_author varchar(10), year_ed int )
    AS $$
BEGIN
	RETURN QUERY
    Select * from news where news.title_news=title_newsR;    
END;
$$ LANGUAGE plpgsql;


