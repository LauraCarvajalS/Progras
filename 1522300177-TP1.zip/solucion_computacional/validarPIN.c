#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char* validarPin(char *ruta) 
{
  //Se definen las variables que nos ayudarán a leer los certificados.
  FILE* archivo;
  char buf[20];
  char *pin = (char *) malloc(sizeof(char) * 20);
  int cont = 1;
  archivo = fopen(ruta, "r");
  
  //Se verifica que el archivo exista
  if (archivo == NULL) 
  {
    printf("Error: No existe el certificado del usuario: %s.\n",ruta);
	  return 1;
  }  
  //Se lee línea por línea el txt
  while (fscanf(archivo, "%s", buf)!= EOF)
  {
	  //Se obtiene el pin
	  if (cont==17)
	  {
		  pin[0] = buf[0];
		  pin[1] = buf[1];
		  pin[2] = buf[2];
		  pin[3] = buf[3];
		  pin[4] = buf[4];
		  printf("\t-----------Corroboración: Pin: %s.-----------\n\n",pin);
		  return pin;
	  }
	  cont++;
  }
  fclose(archivo);
}