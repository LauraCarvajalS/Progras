#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static ConsultarCertificados() 
{
  //Se definen las variables que nos ayudarán a leer los certificados.
  FILE* archivo;
  FILE* certificado;
  char buf[500];
  char buff[500];
  char stringF[500] = "";
  int count = 0;
  archivo = fopen("listaCertificados.txt", "r");
  
  printf("Lista de certificados:");
  printf("\n*****************************************\n");
  
  //Se verifica que el archivo 'listaCertificados.txt' exista
  if (archivo == NULL) 
  {
    printf("Error: No hay certificados registrados.\n");
    main();
  }
  
  //Se lee línea por línea el txt
  while (fscanf(archivo, "%s", buf)!= EOF)
  {
    printf("Certificado: %s\n",buf);
    certificado = fopen(buf,"r");
    if (certificado == NULL) 
    {
      printf("\tError: El certificado fue revocado.\n");
    }
    else
    {
      //Se muestra el contenido de los certificados.
      while (fscanf(certificado, "%s", buff)!=EOF)
      {
        printf("\t%s\n",buff);
      }
      fclose(certificado);
    }
    printf("*****************************************\n");
  }
  fclose(archivo);
  main();
}
