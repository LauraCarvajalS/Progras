#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static revocarCertificado()
{	
    //Se guarda el nombre que el usuario ingrese en consola
    char identificacion[15];
    printf("\n\tIngrese el numero de identificación del usuario dueño del certificado a revocar: ");
    scanf("%s",&identificacion);
    printf("\n");
    
    char kp1[22];
    strcat(kp1,identificacion);
    strcat(kp1,"Privada.pem");
    
    char kp2[22];   
    strcat(kp2,identificacion);
    strcat(kp2,"Publica.pem");
    
    strcat(identificacion,".txt");
    
    
    //Se declara un file con el cual se comparará si el certificado a revocar existe en el sistema.
    FILE *cp;
    
    //Se valida si el certificado existe
    if((cp=fopen(identificacion,"r"))==NULL)
	{ 
        fprintf(stderr, "%s\n","Error: El certificado no se encuentra registrado en el sistema");
        main();
    }
    
    //Se elimina el certificado
    if(remove(identificacion)==0)
    {
        fprintf(stderr, "%s\n","Enhorabuena: El certificado ha sido revocado con exito.");
        
    }
    else
    {
        fprintf(stderr, "%s\n","Error: No se logró revocar el certificado.");
    }

    fclose(cp);//Cerramos el archivo 
    main();
}
