#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static validarDocumento()
{
	// Variable que contendrá la ruta de donde estara el documento firmado
    char ruta[100]; 
    printf("\tPor favor ingrese la ruta en la que se encuentra el documento firmado(.txt_signed.txt):");
    scanf("%s",ruta);
    printf("\n");
    
	char docto[100]; 
    printf("\tPor favor ingrese la ruta en la que se encuentra el documento original(.txt):");
    scanf("%s",docto);
    printf("\n");
	
	int identificacion;
    printf("\tPor favor ingrese la identificación del usaurio que firmó el documento(9 dígitos):");
    scanf("%d",identificacion);
    printf("\n");
	
	printf("\t--------El documento es válido--------\n");
}	
	//Obtener doc original
	
	//Sacar resumen del doc original
	
	//Obtener llave pública del usuario que firmó el documento
	
	//Comparar los resúmenes
