#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/rsa.h>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>


static char *hashing(char *texto,int id,char *ruta)
{
    //Se crea una variable que servirá como contador
    int i = 0;
    
    //Se crea un char auxiliar en el cual se almacenará el hash del documento
    char *auxiliar;
    unsigned char temporal[SHA_DIGEST_LENGTH];
    char buffer[SHA_DIGEST_LENGTH*2];

    FILE *llave;
    char *lineas;
    char leido;
    int cantidad=0;

    char aux[10000];
    char leido3[10000];
    
    //Se copia el texto '0x0' SHA_DIGEST_LENGTH*2 veces en la cadena buffer.    
    memset(buffer, 0x0, SHA_DIGEST_LENGTH*2);
    
    //Se copia el texto '0x0' SHA_DIGEST_LENGTH veces en la cadena temporal.
    memset(temporal, 0x0, SHA_DIGEST_LENGTH);
 
    //SHA1((unsigned char *)texto, strlen(texto), temporal);
 
    for (i=0; i < SHA_DIGEST_LENGTH; i++) 
    {
        sprintf((char*)&(buffer[i*2]), "%02x", temporal[i]);
    }
    auxiliar=buffer;
    
    //Se crea el file archivoAuxiliar el cual servirá para copiar la llave del 
    FILE *archivoAuxiliar;
    archivoAuxiliar =fopen("hash.txt","w");
    
    fprintf(archivoAuxiliar, "%s\n",auxiliar);
    fclose(archivoAuxiliar);
    
    //Se crea una cadena de texto para almacenar el comando de encriptación.
    char comando[35];
    comando[0]='o';
    comando[1]='p';
    comando[2]='e';
    comando[3]='n';
    comando[4]='s';
    comando[5]='s';
    comando[6]='l';
    comando[7]=' ';
    comando[8]='r';
    comando[9]='s';
    comando[10]='a';
    comando[11]='u';
    comando[12]='t';
    comando[13]='l';
    comando[14]=' ';
    comando[15]='-';
    comando[16]='e';
    comando[17]='n';
    comando[18]='c';
    comando[19]='r';
    comando[20]='y';
    comando[21]='p';
    comando[22]='t';
    comando[23]=' ';
    comando[24]='-';
    comando[25]='i';
    comando[26]='n';
    comando[27]='k';
    comando[28]='e';
    comando[29]='y';
    comando[30]=' ';
    comando[31]='\0';
    
    //Se concatena la identificación con 'Publica.pem' para así obtener el nombre del archivo que contiene la llave pública.
    char idAux2[15];
    sprintf(idAux2,"%d",id);
    strcat(idAux2,"Publica.pem");

    //Se concatena el archivo.pem al comando
    strcat(comando,idAux2);
    strcat(comando," -pubin -in hash.txt ");
    strcat(comando,"-out ");

    //Se concatena la identificación con '.enc' para así obtener el archivo que contiene la firma.
    char idAux3[15];
    sprintf(idAux3,"%d",id);
    strcat(idAux3,".enc");
    strcat(comando,idAux3); 

    //Se manda a ejecutar el comando de encriptación.
    system(comando);
    
    archivoAuxiliar = fopen(idAux3,"r");

    //Se copian los caracteres leídos del archivoAuxiliar en la cadena de texto 'docto'
    while (fgets(leido3, sizeof(leido3), archivoAuxiliar)) 
    {  
        //Se concatena la información de 'docto' en la cadena 'aux'
        strcat(aux,leido3);
    }
    fclose(archivoAuxiliar);
    
    //Se sobre escribe los datos de 'auxiliar' (hash)
    strcpy(auxiliar,aux);
    
    //Se retorna el hash del documento.
    return auxiliar;    
}