#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.c"
#include "validarPIN.c"

static firmaDocumento()
{
    char ruta[100]; // Variable que contendra la ruta de donde estara el documento a firmar
    printf("\tPor favor ingrese la ruta en la que se encuentra el documento (.txt):");
    scanf("%s",ruta);
    printf("\n");

    // Aqui se almacenara la identificacion del usuario que  frimara el documento
    int identificacion;
    printf("\tPor favor ingrese la identificacion del usuario dueño del certificado:");
    scanf("%d",&identificacion);
    
    //Se asigna una copia de la identificación, la cual se usará para concatenar el '.txt' y así abrir el certificado.
    char nombreArchivo[15];
    sprintf(nombreArchivo,"%d",identificacion);// Se convierte del tipo entero a cadena
        
    printf("\n");

    char pin[5]; // Aqui se almacenara el pin del usuario que  frimara el documento
    printf("\tPor favor ingrese el pin del certificado:");
    scanf("%s",&pin);
    printf("\n"); 

    strcat(nombreArchivo,".txt");
    
    FILE* archivo;
    archivo = fopen(nombreArchivo, "r");
    //Se verifica que el certificado exista
    if (archivo != NULL) 
    {
        printf("\t-----------Corroboración: Identificación: %d.-----------\n",identificacion);
        char* pin1 = validarPin(nombreArchivo);
	    if(pin1 != 1 && strcmp(pin,pin1)==0)
        {
            //Se crean los file que servirán para leer/crear el certificado, el documento y el documento firmado.
            FILE *nuevo;
            FILE *original;
            FILE *original3;

            
            char leido2[2700];
            char leido3[15000];
            char nombreRuta[1500];
            
            strcpy(nombreRuta,ruta);
            strcat(nombreRuta,"_signed.txt");

            original = fopen(ruta,"r"); 
            nuevo = fopen(nombreRuta,"w");

            //Se escribe en el nuevo documento
            fprintf(nuevo, "%s","@@ORIGINAL TEXT@@");
            fprintf(nuevo, "%s","\n" );
            fprintf(nuevo, "%s","\n" );

            //Se lee el documento a firmar y se escribe su contenido en el archivo del documento firmado.
            while (fgets(leido2, sizeof(leido2), original)) 
            {		
                fprintf(nuevo, "%s",leido2);
            }  

            fprintf(nuevo, "%s","\n" );
            fprintf(nuevo, "%s","\n" );  
            fprintf(nuevo, "%s","@@DIGITAL SIGNATURE@@");
            fprintf(nuevo, "%s","\n" );

            original3 = fopen(ruta,"r");
            
            //aux almacenará el texto del documento a firmar, esto para usarlo a la hora de realizar el hash del documento.
            char aux[10000];
            
            //Se copian los caracteres leídos de 'original3' en la cadena de texto 'leido3'
            while (fgets(leido3, sizeof(leido3), original3)) 
            {
                strcat(aux,leido3);
            }
            fclose(original3);


            //Se hace el hash del documento y ese texto se almacena en la variable 'hashTexto'
            char *hashTexto;
            int puntero=0;
            hashTexto = hashing(aux,identificacion,ruta);
            fprintf(nuevo,"%s","\n" );

            while(hashTexto[puntero]!='\0')
            {
                fprintf(nuevo, "%c",hashTexto[puntero]);
                puntero++;
            }  

            fprintf(nuevo, "%s","\n" );
            fprintf(nuevo, "%s","\n" );  
            fprintf(nuevo, "%s","@@DATE@@");
            fprintf(nuevo, "%s","\n" );

            //Se obtine la fecha actual
            time_t t = time(NULL);
            struct tm tm = *localtime(&t);
            
            fprintf(nuevo, "%s","\n" );  
            fprintf(nuevo, " %d-%d-%d \n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
            fprintf(nuevo, "%s","\n" );

            //Se crea el file para leer el certificado del usuario
            FILE *usuario;
            char *renglon;
            int largo=0;
            char obtenido;

            //Se crea el file para leer la llave del usuario
            FILE *archivoLlave;
            char *lineasLlave;
            int cantidadLlave=0;
            char leidoLlave;

            usuario = fopen(nombreArchivo,"r");

            fprintf(nuevo, "%s","\n" );  
            fprintf(nuevo, "%s","@@CERTIFICATE@@");
            fprintf(nuevo, "%s","\n" );
            
            fprintf(nuevo, "%s","-----CERTIFICATE ID-----");
            fprintf(nuevo, "%s","\n" );

            //Se obtiene la identificación del certificado.
            obtenido = getline(&renglon, &largo, usuario);
            obtenido = getline(&renglon, &largo, usuario);
  
            fprintf(nuevo, "%s",renglon);
            fprintf(nuevo, "%s","\n" );

            obtenido = getline(&renglon, &largo, usuario);
            obtenido = getline(&renglon, &largo, usuario);

            fprintf(nuevo, "%s","-----NAME-----");
            fprintf(nuevo, "%s","\n" );

            //Se obtiene el nombre del dueño del certificado.
            fprintf(nuevo, "%s",renglon);
            fprintf(nuevo, "%s","\n" );


            obtenido = getline(&renglon, &largo, usuario);
            obtenido = getline(&renglon, &largo, usuario);

            fprintf(nuevo, "%s","-----LAST NAME-----");
            fprintf(nuevo, "%s","\n" );
  
            fprintf(nuevo, "%s",renglon);
            fprintf(nuevo, "%s","\n" );

            //Se obtiene el apellido del dueño del certificado.
            obtenido = getline(&renglon, &largo, usuario);
            obtenido = getline(&renglon, &largo, usuario);

            fprintf(nuevo, "%s","-----ID-----");
            fprintf(nuevo, "%s","\n" );

            //Se obtiene la identificación del dueño del certificado.
            fprintf(nuevo, "%s",renglon);
            fprintf(nuevo, "%s","\n" );

            fprintf(nuevo, "%s","-----AUTHORITY-----");
            fprintf(nuevo, "%s","\n" );

            //Se especifica que la firma la está realizando nuestro sistema TUDSS
            fprintf(nuevo, "%s","Trusted Digital Signature System (TUDSS)");
            fprintf(nuevo, "%s","\n" );

            obtenido = getline(&renglon, &largo, usuario);
            obtenido = getline(&renglon, &largo, usuario);

            fprintf(nuevo, "%s","-----KEY SIZE-----");
            fprintf(nuevo, "%s","\n" );

            fprintf(nuevo, "%s",renglon);
            fprintf(nuevo, "%s","\n" ); 

            int size_key=atoi(renglon);

            fprintf(nuevo, "%s","-----BEGIN PUBLIC KEY-----");
            fprintf(nuevo, "%s","\n" );

            fclose(usuario);
            
            //Se obtiene la llave pública (privada) del usuario.
            
            char ideAux[10]; // Variable auxiliar
            sprintf(ideAux,"%d",identificacion);
    
            strcat(ideAux,"Privada.pem");

            archivoLlave = fopen(ideAux,"r");

            leidoLlave = getline(&lineasLlave, &cantidadLlave, archivoLlave);
            while((leidoLlave = getline(&lineasLlave, &cantidadLlave, archivoLlave))!=-1)
            {   
                fprintf(nuevo,"%s",lineasLlave );
            }

            fprintf(nuevo, "%s","-----END PUBLIC KEY-----");

            printf("\n\t-----------El documento se firmó con éxito.-----------\n\n");
            fclose(nuevo);
            main();   
        }
        else
        {
            fprintf(stderr, "%s\n","Error: El pin es incorrecto");
            main();  
        }
    }
    else
    {
        fprintf(stderr, "%s\n","Error: La identificacion es incorrecta");
        main();  
    }
    fclose(archivo);
    main();
}