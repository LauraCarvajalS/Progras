#include <stdio.h>
#include "createCertificados.c"
#include "revocarCertificados.c"
#include "consultaCertificados.c"
#include "firmarDoctos.c"
#include "validarDoctos.c"


main()
{
	//Se crea el menú de opciones
	int option;
	printf("\n-----------------------------------------------------\n\t\tTUDSS\n\n");
	printf("    Menú\n");
	printf("\t1. Crear certificados de Firma digital.\n");
	printf("\t2. Revocar certificados.\n");
	printf("\t3. Certificados registrados.\n");
	printf("\t4. Firmar documento.\n");
	printf("\t5. Validar documento.\n\n\n");
	printf("\t0. Cerrar el programa.\n\n");
	printf("\tEscriba el número correspondiente a la acción de según su interés: ");
	
	scanf("%d",&option);

	//Se especifican las opciones según número.
	if (option==1)
	{
		printf("\n\t\tSe creará el certificado...\n\n");
	    crearCertificados();
	}
	
    if (option==2)
	{
		printf("\n\t\tSe revocará el certificado...\n\n");
        revocarCertificado();
    }
    if (option==3)
	{
		printf("\n\t\tSe listarán los certificados...\n\n");
        ConsultarCertificados();
    }
    if (option==4)
	{
		printf("\n\t\tSe firmará el documento...\n\n");
        firmaDocumento();
    }
    if (option==5)
	{
		printf("\n\t\tSe validará el documento...\n\n");
        validarDocumento();
    }
    if (option==0)
	{
		printf("\n\t\tSe cerrará el programa\n\n");
        exit(0);
    }
}
