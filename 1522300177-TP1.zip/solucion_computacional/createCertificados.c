#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static crearCertificados()
{
    srand (time(NULL));
    int id = rand();//Se crea un número random para el ID del certificado

	printf("\n\tIngrese los datos de usuario\n");//Se le piden los datos al usuario 
	printf("\n");

    //Se guarda el nombre que el usuario ingrese en consola
	char nombre[15];
    printf("\tPrimer nombre: ");
    scanf("%s",nombre);
    printf("\n");

    //Se guarda el apellido que el usuario ingrese en consola
    char apellido[20];
    printf("\tPrimer apellido: ");
    scanf("%s",apellido);
    printf("\n");
    
    //Se guarda la identificación que el usuario ingrese en consola
    int identificacion;
    int identificacion2;
    printf("\tIdentificación: ");
    scanf("%d",&identificacion);
    printf("\n");
    identificacion2=identificacion;


    // Esta variable contendra la identificacion del usuario para que se almacenada en el certificado de manera correcta
    char nombreArchivo2[15];
    sprintf(nombreArchivo2,"%d",identificacion);// Se convierte del tipo entero a cadena

    //Se crea el nombre del archivo txt que almacenará la información del usuario
    char nombreArchivo[15]; 
    sprintf(nombreArchivo,"%d",identificacion);
    strcat(nombreArchivo,".txt");

    //Se crea/abre el archivo donde se almacenará la lista de certificados
    FILE *listaCertificados;
    listaCertificados = fopen("listaCertificados.txt","a"); 
    fprintf(listaCertificados,"%s\n",nombreArchivo);
    fclose(listaCertificados);
    
    //Se guarda el pin que el usuario ingrese en consola
    int pin;
    printf("\tPin: ");
    scanf("%d",&pin);
    printf("\n");

    //Se crea una variable que almacenará el tamaño de la llave que el usuario elija
    int tamano;
    //Esta variable tendra el valor de la opción que el usuario elija
    char opcion;
    printf("\tSeleccione el tamaño de la llave: \n");
    printf("\t\ta.1024\n");
    printf("\t\tb.2048\n");
    scanf("%s",&opcion); 
    printf("\n\n");
    printf("Se generará la llave: \n\n");

    //Se guarda en la variable 'tamano' el tamaño de la llave según la elección del usuario
    if(opcion=='a' || opcion=='A' )
    {
       tamano = 1024;
    }    
    if(opcion=='b'|| opcion=='B' )
    {
       tamano = 2048;
    }

    //Se crea el archivo que almacenará la información del usuario
    FILE *docCertificado;
    docCertificado = fopen(nombreArchivo,"w"); 

    sprintf(nombreArchivo,"%d",identificacion);
    
    //Se almacena la información en el archivo
    fprintf(docCertificado, "%s\n","ID Certificado;"); 
    fprintf(docCertificado, "%d",id);
    fprintf(docCertificado, "%s","\n" );
    fprintf(docCertificado, "%s\n","Primer nombre:");
    fprintf(docCertificado, "%s",nombre);
    fprintf(docCertificado, "%s","\n" );
    fprintf(docCertificado, "%s\n","Primer apellido:");
    fprintf(docCertificado, "%s",apellido);
    fprintf(docCertificado, "%s","\n" );
    fprintf(docCertificado, "%s\n","Identificación:");
    fprintf(docCertificado, "%s",nombreArchivo2);
    fprintf(docCertificado, "%s","\n" );
    fprintf(docCertificado, "%s\n","Tamaño de llave:");
    fprintf(docCertificado, "%d",tamano);
    fprintf(docCertificado, "%s","\n" );
    fprintf(docCertificado, "%s\n","Pin:");
    fprintf(docCertificado, "%d",pin);  
    fprintf(docCertificado, "%s","\n" );

    //Se crea la variable 'writePrivateKey' en la cual se pone el comando 'openssl genrsa -out \0' el cual crea la llave pública
    char writePrivateKey[15];
        writePrivateKey[0]='o';
        writePrivateKey[1]='p';
        writePrivateKey[2]='e';
        writePrivateKey[3]='n';
        writePrivateKey[4]='s';
        writePrivateKey[5]='s';
        writePrivateKey[6]='l';
        writePrivateKey[7]=' ';
        writePrivateKey[8]='g';
        writePrivateKey[9]='e';
        writePrivateKey[10]='n';
        writePrivateKey[11]='r';
        writePrivateKey[12]='s';
        writePrivateKey[13]='a';
        writePrivateKey[14]=' ';
        writePrivateKey[15]='-';
        writePrivateKey[16]='o';
        writePrivateKey[17]='u';
        writePrivateKey[18]='t';
        writePrivateKey[19]=' ';
        writePrivateKey[20]='\0';
    
    //Se crea el archivo .pem, o sea la llave privada
    char idAux[10];
    sprintf(idAux,"%s",nombreArchivo2);
    strcat(idAux,"Privada.pem");
   
    char CAUX[20];
    strcpy(CAUX,idAux);
    strcat(writePrivateKey,idAux);
    strcat(writePrivateKey," ");
    
    char tamanoAux[4];
    sprintf(tamanoAux,"%d",tamano);
    strcat(writePrivateKey,tamanoAux);
    system(writePrivateKey);

    //Se crea la variable 'writePublicKey' en la cual se pone el comando 'openssl rsa -in \0' el cual crea la llave privada
    char writePublicKey[25];
        writePublicKey[0]='o';
        writePublicKey[1]='p';
        writePublicKey[2]='e';
        writePublicKey[3]='n';
        writePublicKey[4]='s';
        writePublicKey[5]='s';
        writePublicKey[6]='l';
        writePublicKey[7]=' ';
        writePublicKey[8]='r';
        writePublicKey[9]='s';
        writePublicKey[10]='a';
        writePublicKey[11]=' ';
        writePublicKey[12]='-';
        writePublicKey[13]='i';
        writePublicKey[14]='n';
        writePublicKey[15]=' ';
        writePublicKey[16]='\0';
     
    //Se crea el archivo .pem, o sea la llave pública
    char idAux2[10];
    sprintf(idAux2,"%s",nombreArchivo2);
    strcat(idAux2,"Publica.pem");
    strcat(writePublicKey,CAUX);
    strcat(writePublicKey," -out ");
    strcat(writePublicKey,idAux2);
    strcat(writePublicKey," -outform PEM -pubout");
    system(writePublicKey);

    //Se crea el archivo .enc, o sea se encripta la llave privada
    char idAux3[10];
    sprintf(idAux3,"%s",nombreArchivo2);
    strcat(idAux3,"Privada.enc");

    fclose(docCertificado);
    main();
}
